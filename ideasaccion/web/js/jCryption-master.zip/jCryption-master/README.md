**This project has been discontinued.**

For more information please visit:
http://www.jcryption.org/
